SoccerJam+ Public Version

* 	- INSTALLATION, DESCRIPTION
*
* 	- Official updated modified version of original SoccerJam Mod made by OneEyed:
* 		http://forums.alliedmods.net/showthread.php?t=41447	
*
*   - Tournament mod by Doondook:
*		https://github.com/Doondook/soccerjam
*
*	- 	* Public version of Doondook's mod by DK:
*			https://github.com/davidkohout/SoccerjamPlusPublic
*
*		1) Just copy & paste (& overwrite) all files from soccerjamplus.zip at your server. 
*		2) Disable not needed plugins like afk kicker, custom map chooser, camera changer (these updated plugins are included in this mod for better performance).
*		3) Restart from Control Panel.
*			- The .zip file contains all models, sounds, recommended maps, compiled plugin, .sma file with used libraries (include), config & lang files, and latest GEOIP+ by Arkshine.
*
*
*		Config Files: sj_plus_config.cfg - check for further customizations
*					  sj_plus_maps.ini - mapchooser's custom map list
*
* 	- Customizable CVARS/COMMANDS list - PLEASE READ - important info
*
*		Console CMDS:	
*		- showbriefing - shows SJ admin menu
*		- amx_restart - restarts server
*		
*		Chat CMDS:
*		- .reset - reset your skills
*		- .skills [player] - show [player's] skills
*		- .stats [player] - show [player's] stats
*		- .whois - show everyone's country
*		- rtv - rock the vote
*		- .spec - change team to spectators
*		- .cam - toggle camera view
*		- [mapname] - nominate your desired map to be shown on next mapvote
*		
*		Console CVARS:
* 		- sj_multiball (20) - amount of the balls for "multiball" command
* 		     		      (32 balls is the limit to prevent server crashes);
* 		- sj_lamedist (85) - max distance to the opposite goals as far you can score, if there is no opponents in alien zone in moment of shoot (0 to turn off);
*		- sj_antideveloper (0) - enables antideveloper, warns & kicks player if his fps_override or developer is set to 1.
*		- sj_regen (0) - enables global HP regeneration
*		- sj_blockspray (0) - blocks impulse 201 (spray logo)
* 		- sj_alienmin (10.0) - minimal damage done by alien;
* 		- sj_alienmax (12.0) - maximum damage done by alien;	
*		- sj_mapchooser (1) - enables SJ mapchooser - example syntax in sj_plus_maps.ini. Use this one since majority of different mapchoosers don't work right with SJ mods.
*		- sj_afk_enable (1) - if you wish to use an AFK kicker, please use this one as it is fully working, many around alliedmodders are outdated and buggy.
*			- sj_afk_transfer_time (12) - 12*5 (=60) seconds to transfer AFK player spec
*			- sj_afk_kick_time (24) - 24*5 seconds to kick AFK player from server
*			- sj_afk_kick_players (10) - minimum number of players required to be present on server to start kicking AFK players
*		- sj_score - winning score (public mode only);
*		- sj_scoret - current Terrorists score;
*		- sj_scorect - current Counter-Terrorists score;
* 		- sj_idleball (30.0) - idle ball time in seconds.